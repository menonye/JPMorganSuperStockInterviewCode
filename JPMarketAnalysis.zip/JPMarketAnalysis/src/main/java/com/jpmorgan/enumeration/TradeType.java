package com.jpmorgan.enumeration;

public enum TradeType {
	BUY, SELL
}
