package com.jpmorgan.enumeration;

public enum StockType {
	COMMON, PREFERRED
}
