package com.jpmorgan.models;

import java.util.Map;

public class GBCE {

	/**
	 * Calculate share index for GBCE for all stocks
	 */
	public static Double shareOfAllIndexes(Map<String, Stock> stocks) {
		Double shareOfAllIndex = 0.0;
		for(Stock stock: stocks.values()) {
			shareOfAllIndex+=stock.getPrice();
		}
		return Math.pow(shareOfAllIndex, 1.0 / stocks.size());
	}
	
}
