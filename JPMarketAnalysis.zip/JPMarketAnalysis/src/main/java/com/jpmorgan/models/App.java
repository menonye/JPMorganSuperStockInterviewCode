package com.jpmorgan.models;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

import com.jpmorgan.enumeration.StockType;

@Configuration
@ComponentScan
public class App 
{
	private static Log log = LogFactory.getLog(App.class);
	
    @Bean
    Map<String, Stock> pretendDb() {
        HashMap<String, Stock> database = new HashMap<String, Stock>();
        database.put("TEA", new Stock("TEA", StockType.COMMON, 0.0, 0.0, 100.0));
        database.put("POP", new Stock("POP", StockType.COMMON, 8.0, 0.0, 100.0));
        database.put("ALE", new Stock("ALE", StockType.COMMON, 23.0, 0.0, 60.0));
        database.put("GIN", new Stock("GIN", StockType.PREFERRED, 8.0, 0.2, 100.0));
        database.put("JOE", new Stock("JOE", StockType.COMMON, 13.0, 0.0, 250.0));
        return database;
    }

    public static void main( String[] args )
    {
        try {
            ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
            
            // Run dividend and P/E Ratio routines
            @SuppressWarnings("unchecked")
    		Map<String, Stock> virtualDb = context.getBean("pretendDb", Map.class);
            for (Stock stock: virtualDb.values()) {
            	Integer refSell=stock.getRefIdSell();
            	Integer refBuy=stock.getrefIdBuy();
            	log.debug( "Customer Stock Reference Id: "+ refSell +", "+ stock.getSymbol() + " dividend: " + stock.dividend(9.1));
            	log.debug( stock.getSymbol() + " P/E Ratio: " + stock.PERatio(9.1));
                // Record some trades
            	
            	for (int i=1; i <= 10; i++) {
            		Random r = new Random();
            		Integer min = 1;
            		Integer max = 10;
            		double randValue = min + (max - min) * r.nextDouble();
            		stock.buyStock(i, randValue);
            		log.debug("Customer buy RefId: "+refBuy++ +", " +stock.getSymbol() + " bought " + i + " shares at $" + randValue);
            		randValue = min + (max - min) * r.nextDouble();
            		stock.sellStock(i, randValue);
            		log.debug( "Customer Sale RefId: " +refSell++ +", "+stock.getSymbol() + " sold " + i + " shares at $" + randValue);
            		Thread.sleep(1000);
            	}
            	log.debug( stock.getSymbol() + " price: $" + stock.getPrice());
            	log.debug( stock.getSymbol() + " volumeWeightedStockPrice: $" + stock.calculateVolStockPrice());
            }
            Double GBCEallShareIndex = GBCE.shareOfAllIndexes(virtualDb);
            log.debug( "GBCE All Share Index: " + GBCEallShareIndex);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
    }
}
