package com.jpmorgan.models;

import com.jpmorgan.enumeration.TradeType;

public class Trade {
	
	private TradeType type;
	private Integer quantity;
	private Double price;
	private Integer tradeRefId=2203 ;// identifies a customer's order

	

	public TradeType getType() {
		return type;
	}

	public void setType(TradeType type) {
		this.type = type;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
	public Integer getTradeRefId() {
		if(tradeRefId!=null){
			tradeRefId++;
		}
		return tradeRefId;
	}

	public void setTradeRefId(Integer tradeRefId) {
		this.tradeRefId = tradeRefId;
	}

	public Trade( Integer cusRefId,TradeType type, Integer quantity, Double price) {
		this.type=type;
		this.quantity=quantity;
		this.price=price;
		this.tradeRefId=cusRefId;
	}

	@Override
	public String toString(){
		return "Trade [tradeRefId=" + tradeRefId + ",type=" + type + ", quantity=" + quantity + ", price="
				+ price + "]";
	}
}
