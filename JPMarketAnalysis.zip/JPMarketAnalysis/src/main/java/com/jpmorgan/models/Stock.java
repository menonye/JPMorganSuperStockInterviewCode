package com.jpmorgan.models;

import java.util.Date;
import java.util.SortedMap;
import java.util.TreeMap;

import com.jpmorgan.enumeration.StockType;
import com.jpmorgan.enumeration.TradeType;

/**
 * stock management software
 * @author mnwaki
 */
public class Stock {
	
	private String symbol;
	private StockType type;
	private Double lastDividend;
	private Double fixedDividend;
	private Double pValue;
	private Double dividend;
	private Integer refIdBuy=2304;
	private Integer refIdSell=2204;
	
	

	
	private TreeMap<Date, Trade> trades;
    
	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public StockType getType() {
		return type;
	}

	public void setType(StockType type) {
		this.type = type;
	}

	public Double getLastDividend() {
		return lastDividend;
	}

	public void setLastDividend(Double lastDividend) {
		this.lastDividend = lastDividend;
	}
	public Integer getRefIdSell() {
		if(refIdSell!=null){
			refIdSell++;
		}
		return refIdSell;
	}

	public void setRefIdSell(Integer refIdSell) {
		this.refIdSell = refIdSell;
	}


    public Integer getrefIdBuy() {
    	if(refIdBuy!=null){
    		refIdBuy++;
    	}
		return refIdBuy;
	}

	public void setrefIdBuy(Integer refId) {
		this.refIdBuy = refId;
	}

	public Double getFixedDividend() {
		return fixedDividend;
	}

	public void setFixedDividend(Double fixedDividend) {
		this.fixedDividend = fixedDividend;
	}

	public Double getpValue() {
		return pValue;
	}

	public void setpValue(Double pValue) {
		this.pValue = pValue;
	}

	public TreeMap<Date, Trade> getTrades() {
		return trades;
	}

	public void setTrades(TreeMap<Date, Trade> trades) {
		this.trades = trades;
	}

	public Stock(String symbol, StockType type, Double lastDividend, Double fixedDividend, Double value) {
		this.symbol=symbol;
		this.type=type;
		this.lastDividend=lastDividend;
		this.fixedDividend=fixedDividend;
		this.pValue=value;
		this.trades = new TreeMap<Date, Trade>();
	}
	



	@Override
	public String toString() {
		return "Stock [refIdSell=" + refIdSell + ",refIdBuy=" + refIdBuy + ",symbol=" + symbol + ", type=" + type + ", lastDividend="
				+ lastDividend + ", fixedDividend=" + fixedDividend
				+ ", parValue=" + pValue + "]";
	}
	/**
	 * Calculate the dividend based on the quoted price
	 */
	public Double dividend(Double price) {
		switch(this.getType()) {
			case COMMON:
			dividend=getLastDividend()/price;
			return dividend;
			case PREFERRED:
				dividend=getFixedDividend()*getpValue()/price;
				return dividend;
			default:
				return 0.0;
		}
	}
	
	/**
	 * Calculate P/E Ratio based on the specified price
	 */

	public Double PERatio(Double price) {
		return price/this.getLastDividend();
	}

	/**
	 * Buy stock, base on quantity and price
	 * 
	 */
	public void buyStock(Integer quantity, Double price) {
		Trade trade = new Trade(getrefIdBuy(),TradeType.BUY, quantity, price);
		this.trades.put(new Date(), trade);
	}

	
	 // Sell stock,quantity and price
	 
	public void sellStock(Integer quantity, Double price) {
		Trade trade = new Trade(getRefIdSell(),TradeType.SELL, quantity, price);
		this.trades.put(new Date(), trade);		
	}
	
	/**
	 * get the current price of the stock based on the last trade price
	 */
	public Double getPrice(){
		if (this.trades.size() > 0) {
			return this.trades.lastEntry().getValue().getPrice();
		} else {
			return 0.0;
		} 
	}
	
	/**
	 * Calculate the Volume Weighted Stock Price 
	 */
	public Double calculateVolStockPrice() {
		Date now = new Date();
		Date startTime = new Date(now.getTime() - (15 * 60 * 1000));
		SortedMap<Date, Trade> trades = this.trades.tailMap(startTime);
		Double volumeWeigthedStockPrice = 0.0;
		Integer totalQuantity = 0;
		for (Trade trade: trades.values()) {
			totalQuantity += trade.getQuantity();
			volumeWeigthedStockPrice += trade.getPrice() * trade.getQuantity();
		}
		return volumeWeigthedStockPrice/totalQuantity;
	}
}
