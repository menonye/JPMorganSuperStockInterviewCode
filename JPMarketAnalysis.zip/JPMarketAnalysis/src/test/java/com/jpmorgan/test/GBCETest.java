package com.jpmorgan.test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import com.jpmorgan.enumeration.StockType;
import com.jpmorgan.models.GBCE;
import com.jpmorgan.models.Stock;

public class GBCETest {

	@Test
	public void testAllShareIndex() {
        HashMap<String, Stock> db = new HashMap<String, Stock>();
        db.put("TEA", new Stock("TEA", StockType.COMMON, 0.0, 0.0, 50.0));
        db.put("POP", new Stock("POP", StockType.COMMON, 3.0, 0.0, 50.0));
        db.put("ALE", new Stock("ALE", StockType.COMMON, 3.0, 0.0, 50.0));
        db.put("GIN", new Stock("GIN", StockType.PREFERRED,3.0, 0.2, 90.0));
        db.put("JOE", new Stock("JOE", StockType.COMMON, 3.0, 0.0, 150.0));
        for (Stock stock: db.values()) {
         //Trade records
        	for (int i=1; i <= 10; i++) {
        		stock.buyStock(3, 2.49);
        		stock.sellStock(3, 3.58);
        	}
        }
        Double GBCEallShareIndex = GBCE.shareOfAllIndexes(db);
        assertEquals(1.7806173723517893, GBCEallShareIndex, 0.0);
	}

}
