package com.jpmorgan.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

import com.jpmorgan.enumeration.StockType;
import com.jpmorgan.enumeration.TradeType;
import com.jpmorgan.models.Stock;
import com.jpmorgan.models.Trade;

public class StockTest {

	//Test dividend for Common
	@Test
	public void testDividendforCommon() {
        Stock ale = new Stock("ALE", StockType.COMMON, 12.0, 0.1, 34.0);
		Double dividendforALE = ale.dividend(1.0);
		Double totalDividendforALE = ale.getLastDividend()/1.0;
		assertEquals(totalDividendforALE, dividendforALE, 0.0);
	}
	
	//Test dividend for Preferred
	@Test
		public void testDividendforPreferred() {
	        Stock gin = new Stock("GIN", StockType.PREFERRED, 19.0, 0.25, 72.0);   
			Double overalldividforGIN = gin.dividend(1.0);
			Double totalDividendforGIN = gin.getFixedDividend()*gin.getpValue()/1.0;
			assertEquals(totalDividendforGIN, overalldividforGIN, 0.0000001);
		}
		
		

	@Test
	public void testPERatio() {
        Stock ale = new Stock("ALE", StockType.COMMON, 8.0, 0.0, 60.0);
        Double peRatioALE = ale.PERatio(2.0);
        Double expPeRatioALE = 2.0/ale.getLastDividend();
        assertEquals(expPeRatioALE, peRatioALE, 0.0);
	}

	
	@Test
	public void testBuyStock() {
		Stock ale = new Stock("ALE", StockType.COMMON, 8.0, 0.0, 60.0);
		ale.buyStock(1, 10.0);
		assertEquals(10.0, ale.getPrice(), 0.0);
	}

	@Test
	public void testSellStock() {
		Stock ale = new Stock("ALE", StockType.COMMON, 10.0, 0.0, 60.0);
		ale.sellStock(1, 10.0);
		assertEquals(10.0, ale.getPrice(), 0.0);
	}


	@Test
	public void testGetStockPrice() {
		Stock ale = new Stock("ALE", StockType.COMMON, 10.0, 0.0, 60.0);
		ale.sellStock(1, 10.0);
		ale.buyStock(1, 11.0);
		assertEquals(11.0, ale.getPrice(), 0.0);
	}

	
	@Test
	public void testCalculateVolumeWeightedStockPrice() {
		Stock ale = new Stock("ALE", StockType.COMMON, 18.0, 0.1, 40.0);
		ale.sellStock(2, 10.0);
		ale.buyStock(2, 10.0);		
		Double volumeWeightedStockPrice = ale.calculateVolStockPrice();
		assertEquals(10.0, volumeWeightedStockPrice, 0.0);
		Date now = new Date();
		Date tradestartTime = new Date(now.getTime() - (20 * 60 * 1000));
		ale.getTrades().put(tradestartTime, new Trade(ale.getrefIdBuy(),TradeType.BUY, 1, 20.0));  
		
		assertEquals(10.0, volumeWeightedStockPrice, 0.0);
	}
	
}
